(function () {
  'use strict';

  angular
    .module('cafeyoga.layout', [
      'cafeyoga.layout.controllers'
    ]);

  angular
    .module('cafeyoga.layout.controllers', []);
})();