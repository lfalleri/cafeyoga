(function () {
  'use strict';

  var app = angular
    .module('cafeyoga', [
      'cafeyoga.config',
      'cafeyoga.routes',
      'cafeyoga.authentication',
      'cafeyoga.yoga',
      'cafeyoga.restaurant',
      'cafeyoga.layout',
      'cafeyoga.utils',
    ]);

  angular
    .module('cafeyoga.routes', ['ngRoute']);

  angular
    .module( 'cafeyoga.config',[]);

  angular
    .module('cafeyoga')
    .run(run);

   run.$inject = ['$http', '$location', '$rootScope'];

   /**
   * @name run
   * @desc Update xsrf $http headers to align with Django's defaults
   */
   function run($http, $location, $rootScope) {
     $http.defaults.xsrfHeaderName = 'X-CSRFToken';
     $http.defaults.xsrfCookieName = 'csrftoken';


     var history = [];
     $rootScope.$on('$routeChangeSuccess', function() {
        history.push($location.$$path);
        console.log("history : ", history);
     });
     $rootScope.back = function () {
        var prevUrl = history.length > 1 ? history.splice(-2)[0] : "/";
       console.log("prevUrl : ", prevUrl);
       $location.path(prevUrl);
     };

   }

  app.filter('isEmpty', [function() {
    return function(object) {
       return angular.equals({}, object);
    }
  }]);

})();