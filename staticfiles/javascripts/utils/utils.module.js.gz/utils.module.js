(function () {
  'use strict';

  angular
    .module('cafeyoga.utils', [
      'cafeyoga.utils.services'
    ]);

  angular
    .module('cafeyoga.utils.services', []);
})();